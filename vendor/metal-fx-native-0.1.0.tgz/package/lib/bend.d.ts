import { type SharedValue } from 'react-native-reanimated';
import { type Pt } from './geometry';
export interface BendConfig {
    enabled: boolean;
    strength: number;
    blob: number;
    liquidBlob: number;
    maxDisp: number;
    liquid: number;
    stiffness: number;
    damping: number;
    mass: number;
    liquidStiffness: number;
    liquidDamping: number;
    follow: number;
    smoothMs: number;
    fadeInMs: number;
    fadeOutMs: number;
    /** Tilt (fraction of g on the screen plane) at which the dent is full. */
    tiltRange: number;
    tiltDeadzone: number;
}
export declare const BEND_DEFAULTS: BendConfig;
export interface BendField {
    cx: number;
    cy: number;
    dirX: number;
    dirY: number;
    radK: number;
    s2b: number;
    s2l: number;
    reach: number;
}
export declare function deformPoint(f: BendField, x: number, y: number): Pt;
/** Manual tilt (x right, y down, in g) for tests and the simulator; null = sensor. */
export declare const tiltOverride: SharedValue<{
    dx: number;
    dy: number;
} | null> | null;
/**
 * Screen-plane tilt relative to a slowly adapting baseline, so a tilt reads
 * as a gesture and the resting pose settles back to neutral.
 */
export declare function useTilt(enabled: boolean, override?: SharedValue<{
    dx: number;
    dy: number;
} | null>): SharedValue<{
    dx: number;
    dy: number;
}>;
/**
 * Per-instance bend simulation on the UI thread. `size` and `radius` are
 * shared values from the host's layout; `field` is null while idle.
 */
export declare function useBendField(tilt: SharedValue<{
    dx: number;
    dy: number;
}>, size: SharedValue<{
    width: number;
    height: number;
}>, radius: SharedValue<number>, cfg: BendConfig, enabled: boolean): SharedValue<BendField | null>;
