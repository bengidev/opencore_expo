import React, { type ReactNode } from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import { Skia } from '@shopify/react-native-skia';
import { type SharedValue } from 'react-native-reanimated';
import { type MetalPreset, type MetalTheme } from './material';
import { type BendConfig } from './bend';
import { type GlowConfig } from './glow';
export declare function liquidMetalEffect(): import("@shopify/react-native-skia").SkRuntimeEffect;
/** Material time in seconds, shared across instances, pause-aware. */
export declare function useMetalTime(paused: boolean): SharedValue<number>;
export interface MetalFxProps {
    variant?: 'button' | 'circle';
    preset?: MetalPreset;
    theme?: MetalTheme;
    /** 0..1 — multiplies the material's opacity and the glow. */
    strength?: number;
    /** Defaults to the variant's (button 1.6, circle 1.3). */
    shaderScale?: number;
    /** Band width, pt; defaults to the variant's (button 1, circle 2). */
    ringWidth?: number;
    /** Defaults to fully rounded. */
    cornerRadius?: number;
    /** The Figma inner-shadow hairline along the band's top inside edge. */
    innerShadow?: boolean;
    glow?: boolean;
    glowGain?: number;
    paused?: boolean;
    /** Bend with the phone's tilt. */
    tilt?: boolean;
    bendConfig?: BendConfig;
    glowConfig?: GlowConfig;
    /** Surface colour under the content; defaults to the theme's. */
    fill?: string;
    /** Anchor id for `MetalReflection` / `MetalEdgeHalo`. */
    id?: string;
    /** Manual tilt (x right, y down, in g) for the simulator; null = sensor. */
    tiltOverride?: SharedValue<{
        dx: number;
        dy: number;
    } | null>;
    style?: StyleProp<ViewStyle>;
    children?: ReactNode;
}
/**
 * The liquid-metal ring around any content — metal-fx v2's `<MetalFx>`.
 * Wraps `children` tightly; the band runs along their edge with the glow,
 * rims and inner shadow between the two. The whole animation runs on the UI
 * thread: time, tilt, bend physics, glow and shader uniforms are shared
 * values — React never re-renders per frame.
 */
export declare function MetalFx({ variant, preset, theme, strength, shaderScale, ringWidth, cornerRadius, innerShadow, glow, glowGain, paused, tilt, bendConfig, glowConfig, fill, id, tiltOverride, style, children, }: MetalFxProps): React.JSX.Element;
/** The Figma inner shadow: the band minus itself shifted down. A plain
 *  layer with `dstOut` (anti-aliased paths); clips would give jagged edges
 *  and a blur-filter layer next to the glow's mask leaked over the canvas. */
export declare function InnerShadow({ band, offsetY, alpha }: {
    band: SharedValue<ReturnType<typeof Skia.Path.Make>>;
    offsetY?: number;
    alpha?: number;
}): React.JSX.Element;
