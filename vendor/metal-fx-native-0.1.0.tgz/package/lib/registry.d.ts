import type { SharedValue } from 'react-native-reanimated';
import type { MetalMaterial, SheetMapping } from './material';
import type { ShapeKind } from './geometry';
import type { BendField } from './bend';
export interface AnchorFrame {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** The screen-edge lens a `MetalEdgeHalo` puts on a ring; distances in pt,
 *  coordinates local to the ring's box (`edge` 0 left, 1 right, 2 top, 3 bottom). */
export interface EdgeLens {
    edge: number;
    edgeCoord: number;
    centerAlong: number;
    halfLen: number;
    depth: number;
    intensity: number;
    displacement: number;
}
export interface MetalAnchor {
    id: string;
    frame: AnchorFrame;
    width: number;
    height: number;
    cornerRadius: number;
    ringWidth: number;
    kind: ShapeKind;
    material: MetalMaterial;
    mapping: SheetMapping;
    opacityMul: number;
    /** Text / badge: the whole box is metal (a masked sheet), not a band. */
    isSheet: boolean;
    /** Material time, seconds (pause-aware), on the UI thread. */
    time: SharedValue<number>;
    /** The bend field for this frame, or null when idle. */
    field: SharedValue<BendField | null>;
    /** Rings only: the edge lens (see `MetalEdgeHalo`), on the UI thread. */
    lens?: SharedValue<EdgeLens | null>;
    /** Rings only: switch the lens filter on or off (a React re-render). */
    setLensActive?: (on: boolean) => void;
}
export declare function registerMeasurer(fn: () => void): () => void;
/**
 * Re-measure every anchor and reflection target in window coordinates.
 * Frames are otherwise read on layout only, so call this from a ScrollView's
 * `onScroll` (with `scrollEventThrottle`) or after any move without a layout.
 */
export declare function refreshMetalFrames(): void;
export declare function registerAnchor(a: MetalAnchor): void;
export declare function unregisterAnchor(id: string, a: MetalAnchor): void;
/** Frames change rarely; publish only real moves. */
export declare function updateAnchorFrame(a: MetalAnchor, f: AnchorFrame): void;
export declare function updateAnchorLook(a: MetalAnchor, patch: Partial<MetalAnchor>): void;
export declare function getAnchor(id: string): MetalAnchor | undefined;
export declare function allAnchors(): MetalAnchor[];
/** Re-render when any anchor registers, moves or changes its look. */
export declare function useAnchorsVersion(): number;
export declare function useAnchor(id: string): MetalAnchor | undefined;
/** One time base for every instance. */
export declare const CLOCK_EPOCH: number;
