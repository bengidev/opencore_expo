import React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import { type SkFont } from '@shopify/react-native-skia';
import { type MetalPreset, type MetalTheme } from './material';
import { type GlowConfig } from './glow';
export interface MetalTextProps {
    children: string;
    fontSize?: number;
    fontWeight?: '400' | '500' | '600' | '700' | 'normal' | 'bold';
    fontFamily?: string;
    /** Base colour under the metal. */
    color?: string;
    preset?: MetalPreset;
    theme?: MetalTheme;
    strength?: number;
    metalOpacity?: number;
    shaderScale?: number;
    innerShadow?: boolean;
    glow?: boolean;
    glowGain?: number;
    paused?: boolean;
    glowConfig?: GlowConfig;
    id?: string;
    style?: StyleProp<ViewStyle>;
}
export declare function useMetalFont(fontSize: number, fontWeight: MetalTextProps['fontWeight'], fontFamily?: string): SkFont;
/** Text metrics: width, and the baseline / box height from the font. */
export declare function measureLabel(font: SkFont, text: string): {
    width: number;
    height: number;
    baseline: number;
};
/**
 * Metal inside the glyphs of a word — metal-fx v2's `<MetalText>`. Drawn
 * entirely in Skia so the letterforms, the material and the inner shadow
 * share one raster.
 */
export declare function MetalText({ children: text, fontSize, fontWeight, fontFamily, color, preset, theme, strength, metalOpacity, shaderScale, innerShadow, glow, glowGain, paused, glowConfig, id, style, }: MetalTextProps): React.JSX.Element;
