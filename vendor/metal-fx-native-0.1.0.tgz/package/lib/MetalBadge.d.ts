import React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import { type MetalPreset, type MetalTheme } from './material';
export interface MetalBadgeCore {
    r: number;
    blur: number;
    a: number;
    size: number;
}
export interface MetalBadgeProps {
    children?: string;
    preset?: MetalPreset;
    theme?: MetalTheme;
    strength?: number;
    /** Size multiplier on the Figma metrics (45×25, 12.222 pt). */
    scale?: number;
    metalOpacity?: number;
    shaderScale?: number;
    core?: MetalBadgeCore;
    gradient?: number;
    glow?: number;
    textColor?: string;
    paused?: boolean;
    id?: string;
    style?: StyleProp<ViewStyle>;
}
export declare const METAL_BADGE_DEFAULTS: {
    metalOpacity: number;
    shaderScale: number;
    core: MetalBadgeCore;
    gradient: number;
    glow: number;
};
/**
 * The "New" badge (Figma 1458:40880): a white pill with the material over
 * it, a clean white core under the label so the metal lives at the rim, the
 * inset white glows and hairlines, and the label.
 */
export declare function MetalBadge({ children: text, preset, theme, strength, scale, metalOpacity, shaderScale, core, gradient, glow, textColor, paused, id, style, }: MetalBadgeProps): React.JSX.Element;
