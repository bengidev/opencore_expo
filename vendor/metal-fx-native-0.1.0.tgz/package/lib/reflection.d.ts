import React, { type ReactNode } from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
export interface MetalReflectionProps {
    /** The anchor's id. */
    of: string;
    /** Alpha multiplier (1 = canonical; the demo's "Plan" uses 0.64). */
    strength?: number;
    /** This view's corner radius; defaults to fully rounded. */
    cornerRadius?: number;
    style?: StyleProp<ViewStyle>;
    children?: ReactNode;
}
/**
 * Reflect the metal of anchor `of` onto this view's facing edge — metal-fx
 * v2's `reflectionTargets`. Wraps `children`; the reflection is a Skia
 * overlay on top of them, clipped to the view's rounded rect.
 */
export declare function MetalReflection({ of, strength, cornerRadius, style, children }: MetalReflectionProps): React.JSX.Element;
export interface MetalReflectionTextProps {
    of: string;
    children: string;
    fontSize?: number;
    fontWeight?: '400' | '500' | '600' | '700' | 'normal' | 'bold';
    fontFamily?: string;
    color?: string;
    strength?: number;
    style?: StyleProp<ViewStyle>;
}
/**
 * A word that catches the metal on its letterforms (the demo's "Plan").
 * Drawn in Skia so the glyphs can mask the mirrored sheet.
 */
export declare function MetalReflectionText({ of, children: text, fontSize, fontWeight, fontFamily, color, strength, style }: MetalReflectionTextProps): React.JSX.Element;
