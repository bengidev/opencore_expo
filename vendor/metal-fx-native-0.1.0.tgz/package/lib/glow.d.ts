/**
 * The wandering halo — the web's glow state machine (luminance hunt, dwell,
 * fade-out / fade-in relocation, wander, tint hold) as a UI-thread worklet,
 * plus the baked halo / catch-light sprites (Skia offscreen surfaces).
 */
import { type SkImage } from '@shopify/react-native-skia';
import { type Pt, type ShapeKind } from './geometry';
export interface GlowConfig {
    haloOpMul: number;
    extraIntensity: number;
    peakOp: number;
    baseOp: number;
    inset: number;
    extraOutward: number;
    wanderRange: number;
    wanderLerp: number;
    fadeRate: number;
    lumLo: number;
    lumHi: number;
    minDwellMs: number;
    relocFadeMs: number;
    relocFadeOutMs: number;
    pointGain: number;
    haloHalfLen: number;
    extraHalfLen: number;
    haloStrokeXl: number;
    haloStrokeLg: number;
    haloStrokeMd: number;
    haloStrokeSm: number;
    haloBlurXl: number;
    haloBlurLg: number;
    haloBlurMd: number;
    haloBlurSm: number;
    haloOpXl: number;
    haloOpLg: number;
    haloOpMd: number;
    haloOpSm: number;
    extraStrokeOuter: number;
    extraStrokeCore: number;
    extraBlurOuter: number;
    extraBlurCore: number;
    extraFadeR: number;
    extraOpOuter: number;
}
export declare const GLOW_DEFAULTS: GlowConfig;
export interface GlowFrame {
    x: number;
    y: number;
    ex: number;
    ey: number;
    tangent: number;
    haloOp: number;
    extraOp: number;
    env: number;
    tint: [number, number, number];
}
export interface GlowPerim {
    x: number;
    y: number;
    arc: number;
}
/** Mutable glow state, kept in a shared value and stepped by `glowTick`. */
export interface GlowState {
    perim: GlowPerim[];
    pointMode: boolean;
    w: number;
    h: number;
    r: number;
    kind: ShapeKind;
    currentIdx: number;
    glowOpacity: number;
    appearedAt: number;
    relocNextIdx: number;
    tween: {
        from: number;
        to: number;
        dur: number;
        start: number;
        done: boolean;
        val: number;
    } | null;
    relocMul: number;
    envClock: number;
    lastTickMs: number;
    lastHuntMs: number;
    lum: number[];
    wanderS: number;
    wanderTargetS: number;
    wanderMs: number;
    tintFrom: [number, number, number];
    tintTarget: [number, number, number];
    tintTween: {
        from: number;
        to: number;
        dur: number;
        start: number;
        done: boolean;
        val: number;
    } | null;
    tintHoldUntil: number;
}
export declare function initialGlowState(): GlowState;
/** Rebuild the perimeter table when the box (or the glyph mask) changes. */
export declare function configureGlow(s: GlowState, w: number, h: number, r: number, kind: ShapeKind, cfg: GlowConfig, samplePoints?: Pt[] | null): void;
/** Advance the state; returns the frame to draw or null. */
export declare function glowTick(s: GlowState, nowMs: number, lumAt: (x: number, y: number) => number, rgbAt: (x: number, y: number) => [number, number, number], strength: number, light: boolean, deform: ((x: number, y: number) => Pt) | null, cfg: GlowConfig): GlowFrame | null;
export interface GlowSprite {
    image: SkImage;
    w: number;
    h: number;
    scale: number;
}
export declare function haloSprite(halfLen: number, s: number, scale: number, cfg: GlowConfig): GlowSprite;
export declare function extraSprite(halfLen: number, s: number, scale: number, cfg: GlowConfig): GlowSprite;
