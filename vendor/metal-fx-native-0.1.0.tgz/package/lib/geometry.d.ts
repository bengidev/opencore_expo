/**
 * Rounded-rect outline sampling and perimeter math — the web's
 * `renderer/outline.ts` and `glow/geometry.ts`. Worklets, so the bend can
 * rebuild the path on the UI thread every frame.
 */
import { type SkPath } from '@shopify/react-native-skia';
export type ShapeKind = 'pill' | 'circle';
export type Pt = {
    x: number;
    y: number;
};
export type Deform = ((x: number, y: number) => Pt) | null;
/** Clockwise from the end of the top-left corner; flat [x0,y0,x1,y1,…]. */
export declare function roundRectOutline(x: number, y: number, w: number, h: number, radius: number, deform: Deform): number[];
export declare function addOutline(path: SkPath, xy: number[]): void;
/** Outer outline with the inner one punched out (even-odd). */
export declare function bandPath(outer: number[], inner: number[]): SkPath;
export declare function outlinePath(xy: number[]): SkPath;
export declare function shapeKind(w: number, h: number, radius: number): ShapeKind;
export declare function rrPerim(w: number, h: number, r: number): number;
export declare function shapePerim(w: number, h: number, r: number, kind: ShapeKind): number;
export declare function sampleAtArc(sIn: number, w: number, h: number, r: number, inset: number, outward: number, kind: ShapeKind): Pt;
export declare function tangentAngleAtArc(s: number, w: number, h: number, r: number, inset: number, kind: ShapeKind): number;
/** Where a ray from the centre in (dx, dy) leaves the rounded rect. */
export declare function boundaryPoint(w: number, h: number, radius: number, dx: number, dy: number): Pt;
