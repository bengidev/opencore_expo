import React, { type ReactNode } from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
export interface MetalEdgeHaloProps {
    /** Distance from a screen edge within which a ring lights it, pt. */
    reach?: number;
    /** Strip thickness, pt. */
    depth?: number;
    intensity?: number;
    /** Peak pull of the ring toward the edge, pt. */
    displacement?: number;
    style?: StyleProp<ViewStyle>;
    children?: ReactNode;
}
/**
 * The screen-edge halo. Wrap the view that touches the display's edge and
 * contains a ring with an `id` (a card, a bar). When that ring sits within
 * `reach` of the screen's edge, the side of it facing the edge is pulled
 * toward it like liquid glass — a slow undulation with a slight chromatic
 * split and a faint tint in the metal's colour — by a lens filter on the
 * ring's own canvas (a Skia overlay cannot sample React Native views, so
 * the surrounding content stays put).
 */
export declare function MetalEdgeHalo({ reach, depth, intensity, displacement, style, children }: MetalEdgeHaloProps): React.JSX.Element;
