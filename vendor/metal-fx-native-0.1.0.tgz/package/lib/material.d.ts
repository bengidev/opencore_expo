/**
 * Presets, the sheet mapping, and a CPU port of the material for point
 * sampling (glow luminance hunt, halo tint). Same numbers as the web's
 * `src/engine/presets.ts`; the sampler mirrors the SkSL in `shader.ts`.
 *
 * Every function here is a worklet so the glow can run on the UI thread.
 */
export type MetalPreset = 'chromatic' | 'silver' | 'gold';
export type MetalTheme = 'dark' | 'light';
export interface MetalMaterial {
    /** RGBA 0..1, composited under the material. */
    colorBack: [number, number, number, number];
    /** RGBA 0..1 colour-burn tint; alpha is the amount. */
    colorTint: [number, number, number, number];
    speed: number;
    repetition: number;
    softness: number;
    shiftRed: number;
    shiftBlue: number;
    distortion: number;
    contour: number;
    angle: number;
    shaderOpacity: number;
}
export declare function rgba(hex: string): [number, number, number, number];
export declare function presetMaterial(preset: MetalPreset, theme: MetalTheme): MetalMaterial;
/** uv = origin + pos * scale — the web's per-instance crop of the sheet. */
export interface SheetMapping {
    ox: number;
    oy: number;
    sx: number;
    sy: number;
}
export declare const CANONICAL_W = 140;
export declare const CANONICAL_H = 40;
export declare function sheetMapping(width: number, height: number, shaderScale: number): SheetMapping;
/** The same window drawn into another box, optionally mirrored. */
export declare function stretchedMapping(m: SheetMapping, fromW: number, fromH: number, toW: number, toH: number, flipX: boolean, flipY: boolean): SheetMapping;
/** Uniforms for `LIQUID_METAL_SKSL`. */
export declare function materialUniforms(m: MetalMaterial, map: SheetMapping, time: number, opacityMul: number, ditherScale: number): {
    uvOrigin: number[];
    uvScale: number[];
    time: number;
    colorBack: [number, number, number, number];
    colorTint: [number, number, number, number];
    repetition: number;
    softness: number;
    shiftRed: number;
    shiftBlue: number;
    distortion: number;
    contour: number;
    angle: number;
    opacityMul: number;
    ditherScale: number;
};
export declare function snoise(vx: number, vy: number): number;
/** The material at sheet uv, RGB 0..1 (straight, before opacityMul). */
export declare function sampleMaterial(m: MetalMaterial, ux: number, uy: number, time: number): [number, number, number];
export declare function sampleLuminance(m: MetalMaterial, ux: number, uy: number, time: number): number;
