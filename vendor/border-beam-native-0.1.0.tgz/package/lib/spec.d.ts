import type { BorderBeamColorVariant, BorderBeamSize } from './types';
export interface GradientBlob {
    color: string;
    pos: string;
    size: string;
}
export interface ThemeColors {
    strokeOpacity: number;
    innerOpacity: number;
    bloomOpacity: number;
    innerShadow: string;
    saturation: number;
    brightness?: number;
    hairlineOpacity?: number;
}
export interface Oscillator {
    prop: string;
    a: number;
    b: number;
    period: number;
    delay: number;
    unit: string;
}
export declare const beamSpec: {
    specVersion: string;
    sourceLibrary: {
        name: string;
        version: string;
    };
    generated: string;
    reference: string;
    enums: {
        sizes: string[];
        colorVariants: string[];
        themes: string[];
    };
    defaults: {
        size: string;
        colorVariant: string;
        theme: string;
        duration: {
            line: number;
            pulse: number;
            rotate: number;
        };
        hueRange: number;
        lineHueRangeCap: number;
        strength: number;
        brightnessFallback: number;
        fadeInSeconds: number;
        fadeOutSeconds: number;
        fadeEasing: string;
        rotateHueShiftPeriod: number;
        lineBloomHueShiftPeriod: number;
        lineBloomHueRangeBonus: number;
        monoOpacityMultiplier: number;
        monoForcesStaticColors: boolean;
        pulseDriverFps: number;
    };
    sizePresets: {
        sm: {
            borderRadius: number;
            borderWidth: number;
            width: number;
            height: number;
        };
        md: {
            borderRadius: number;
            borderWidth: number;
        };
        line: {
            borderRadius: number;
            borderWidth: number;
        };
        "pulse-outside": {
            borderRadius: number;
            borderWidth: number;
        };
        "pulse-inner": {
            borderRadius: number;
            borderWidth: number;
        };
    };
    sizeThemePresets: {
        sm: {
            dark: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
            };
            light: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
            };
        };
        md: {
            dark: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
            };
            light: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
            };
        };
        line: {
            dark: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
            };
            light: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
            };
        };
        "pulse-outside": {
            dark: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
                brightness: number;
                hairlineOpacity: number;
            };
            light: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
                brightness: number;
                hairlineOpacity: number;
            };
        };
        "pulse-inner": {
            dark: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
                brightness: number;
            };
            light: {
                strokeOpacity: number;
                innerOpacity: number;
                bloomOpacity: number;
                innerShadow: string;
                saturation: number;
                brightness: number;
            };
        };
    };
    palettes: {
        border: {
            colorful: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                spike: {
                    primary: string;
                    secondary: string;
                };
                spikeLt: {
                    primary: string;
                    secondary: string;
                };
            };
            mono: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                spike: {
                    primary: string;
                    secondary: string;
                };
                spikeLt: {
                    primary: string;
                    secondary: string;
                };
            };
            ocean: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                spike: {
                    primary: string;
                    secondary: string;
                };
                spikeLt: {
                    primary: string;
                    secondary: string;
                };
            };
            sunset: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                spike: {
                    primary: string;
                    secondary: string;
                };
                spikeLt: {
                    primary: string;
                    secondary: string;
                };
            };
        };
        small: {
            colorful: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                inner: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
            };
            mono: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                inner: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
            };
            ocean: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                inner: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
            };
            sunset: {
                border: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
                inner: {
                    color: string;
                    pos: string;
                    size: string;
                }[];
            };
        };
        line: {
            colorful: {
                dark: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
                light: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
            };
            mono: {
                dark: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
                light: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
            };
            ocean: {
                dark: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
                light: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
            };
            sunset: {
                dark: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
                light: {
                    color: string;
                    sizeW: number;
                    sizeH: number;
                    offsetX: number;
                    offsetY: number;
                }[];
            };
        };
        lineInner: {
            colorful: {
                color: string;
                sizeW: number;
                sizeH: number;
                offsetX: number;
                offsetY: number;
            }[];
            mono: {
                color: string;
                sizeW: number;
                sizeH: number;
                offsetX: number;
                offsetY: number;
            }[];
            ocean: {
                color: string;
                sizeW: number;
                sizeH: number;
                offsetX: number;
                offsetY: number;
            }[];
            sunset: {
                color: string;
                sizeW: number;
                sizeH: number;
                offsetX: number;
                offsetY: number;
            }[];
        };
        lineBloom: {
            colorful: {
                dark: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
                light: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
            };
            mono: {
                dark: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
                light: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
            };
            ocean: {
                dark: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
                light: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
            };
            sunset: {
                dark: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
                light: {
                    spikes: {
                        color1: string;
                        color2: string;
                    }[];
                };
            };
        };
    };
    rotate: {
        whiteGradientStops: {
            dark: number[][];
            light: number[][];
        };
        bloomGradientStops: {
            dark: number[][];
            light: number[][];
        };
        beamMaskStops: number[][];
        smallMaskStops: number[][];
        innerGradientDerivation: {
            sizeScale: number;
            alpha: number;
            monoAlpha: number;
        };
        innerEdgeMaskPx: number;
        innerShadowBlur: {
            md: number;
            sm: number;
        };
        bloomBlurPx: number;
        spin: {
            from: number;
            to: number;
            easing: string;
        };
    };
    line: {
        keyframes: {
            travel: {
                x: number[][];
                w: number[][];
            };
            edgeFade: number[][];
            breathe: number[][];
            spike: number[][];
            spike2: number[][];
            durationScale: {
                travel: number;
                edgeFade: number;
                breathe: number;
                spike: number;
                spike2: number;
            };
            easing: {
                travel: string;
                edgeFade: string;
                breathe: string;
                spike: string;
                spike2: string;
            };
        };
        beamMaskEllipse: {
            w: number;
            h: number;
            softStop: number[];
        };
        bloomMaskEllipse: {
            w: number;
            h: number;
            softStop: number[];
        };
        whiteHighlight: {
            dark: {
                w: number;
                h: number;
                yOffset: number;
                stops: number[][];
            };
            light: {
                w: number;
                h: number;
                yOffset: number;
                stops: number[][];
                onBlack: boolean;
            };
        };
        bloomGradients: {
            colorful: {
                dark: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
                light: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
            };
            mono: {
                dark: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
                light: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
            };
            ocean: {
                dark: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
                light: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
            };
            sunset: {
                dark: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
                light: ({
                    xPct: number;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                } | {
                    xPct: null;
                    yOffPx: number;
                    w: {
                        base: number;
                        mult: string;
                    };
                    h: {
                        base: number;
                        mult: string;
                    };
                    stops: {
                        r: number;
                        g: number;
                        b: number;
                        a: number;
                        pos: number;
                    }[];
                })[];
            };
        };
        monoBloomExtraBlurPx: number;
        bloomBlurPx: number;
    };
    pulse: {
        ringMap: {
            region: number;
            quad: string;
        }[];
        innerSizes: number[][];
        innerBloom: {
            ci: number;
            region: number;
            quad: string;
            w: number;
            h: number;
        }[];
        outerCore: {
            ci: number;
            region: number;
            quad: string;
            w: number;
            h: number;
            x: string;
            y: string;
        }[];
        outerBloom: {
            ci: number;
            region: number;
            quad: string;
            w: number;
            h: number;
            x: string;
            y: string;
        }[];
        innerCornerAccent: {
            sizePx: number;
            alpha: {
                dark: number;
                light: number;
            };
            fadeStop: number;
        };
        inner: {
            dark: {
                params: {
                    sp: number;
                    dr: number;
                    op: number;
                    gh: number;
                    bs: number;
                    ss: number;
                    ghs: number;
                    huePeriod: number;
                };
                oscillators: {
                    prop: string;
                    a: number;
                    b: number;
                    period: number;
                    delay: number;
                    unit: string;
                }[];
                frozenBloomAlpha: number;
            };
            light: {
                params: {
                    sp: number;
                    dr: number;
                    op: number;
                    gh: number;
                    bs: number;
                    ss: number;
                    ghs: number;
                    huePeriod: number;
                };
                oscillators: {
                    prop: string;
                    a: number;
                    b: number;
                    period: number;
                    delay: number;
                    unit: string;
                }[];
                frozenBloomAlpha: number;
            };
        };
        outside: {
            dark: {
                params: {
                    sp: number;
                    dr: number;
                    op: number;
                    gh: number;
                    bs: number;
                    ss: number;
                    ghs: number;
                    huePeriod: number;
                };
                oscillators: {
                    prop: string;
                    a: number;
                    b: number;
                    period: number;
                    delay: number;
                    unit: string;
                }[];
                frozenBloomAlpha: number;
            };
            light: {
                params: {
                    sp: number;
                    dr: number;
                    op: number;
                    gh: number;
                    bs: number;
                    ss: number;
                    ghs: number;
                    huePeriod: number;
                };
                oscillators: {
                    prop: string;
                    a: number;
                    b: number;
                    period: number;
                    delay: number;
                    unit: string;
                }[];
                frozenBloomAlpha: number;
            };
        };
        huePeriod: {
            "pulse-inner": number;
            "pulse-outside": number;
        };
        outsideConstants: {
            glowScale: {
                x: number;
                y: number;
            };
            glowBlurPx: {
                dark: number;
                light: number;
            };
            bloomBlurPx: {
                dark: number;
                light: number;
            };
            coreInsetPx: number;
            bloomInsetPx: number;
            referenceSize: {
                w: number;
                h: number;
            };
            scaleClamp: {
                min: number;
                max: number;
            };
            hairline: {
                rgb: {
                    dark: number[];
                    light: number[];
                };
            };
        };
        innerBloomBlurPx: number;
        oscillatorCurve: string;
    };
    filters: {
        order: string[];
        hueRotateModel: string;
    };
};
export declare function themePreset(size: BorderBeamSize, theme: 'dark' | 'light'): ThemeColors;
export declare function sizePreset(size: BorderBeamSize): {
    borderRadius: number;
    borderWidth: number;
};
export declare function borderPalette(variant: BorderBeamColorVariant): GradientBlob[];
export declare function smallPalette(variant: BorderBeamColorVariant): {
    border: GradientBlob[];
    inner: GradientBlob[];
};
export interface RGBA {
    r: number;
    g: number;
    b: number;
    a: number;
}
/** Parses "rgb(r, g, b)" / "rgba(r, g, b, a)" / "transparent" (0-1 channels). */
export declare function parseCssColor(css: string): RGBA | null;
/** Parses "33% -7.4%" → { x: 0.33, y: -0.074 }. */
export declare function parsePercentPair(value: string): {
    x: number;
    y: number;
};
/** Parses "70px 40px" → { w: 70, h: 40 } (CSS explicit-size gradient RADII). */
export declare function parsePixelPair(value: string): {
    w: number;
    h: number;
};
