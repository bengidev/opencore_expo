import type { BorderBeamProps } from './types';
/**
 * BorderBeam — animated border beam effect for React Native (Skia).
 *
 * ```tsx
 * <BorderBeam size="md" colorVariant="ocean" borderRadius={16}>
 *   <Card />
 * </BorderBeam>
 * ```
 */
export declare function BorderBeam({ children, size, colorVariant, theme, staticColors, duration, active, borderRadius, brightness, saturation, hueRange, strength, tuning, style, onActivate, onDeactivate, }: BorderBeamProps): import("react").JSX.Element;
export default BorderBeam;
