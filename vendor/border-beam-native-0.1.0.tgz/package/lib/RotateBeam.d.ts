import { type SharedValue } from 'react-native-reanimated';
import type { BorderBeamColorVariant } from './types';
export interface RotateBeamProps {
    size: 'sm' | 'md';
    variant: BorderBeamColorVariant;
    theme: 'dark' | 'light';
    staticColors: boolean;
    duration: number;
    borderRadius: number;
    brightness: number;
    saturation: number;
    hueRange: number;
    strength: number;
    width: number;
    height: number;
    /** Milliseconds clock (Skia useClock). */
    clock: SharedValue<number>;
    /** 0..1 fade shared value (activate/deactivate). */
    fade: SharedValue<number>;
}
/**
 * The three rotate-family layers, mirroring the web z-order: inner glow (1),
 * stroke ring (2), blurred bloom ring (3).
 */
export declare function RotateBeam({ size, variant, theme, staticColors, duration, borderRadius, brightness, saturation, hueRange, strength, width, height, clock, fade, }: RotateBeamProps): import("react").JSX.Element | null;
