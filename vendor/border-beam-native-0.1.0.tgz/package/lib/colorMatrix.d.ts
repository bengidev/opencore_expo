/**
 * CSS filter chain `hue-rotate(θ) brightness(b) saturate(s)` as a 3x3 matrix,
 * using the W3C feColorMatrix math browsers use (NOT a true HSL rotation).
 * Identical to BorderBeamKit's BeamColorMatrix — keep both in sync.
 */
export declare function hueRotateMatrix(degrees: number): number[];
export declare function saturateMatrix(s: number): number[];
export declare function multiply3x3(a: number[], b: number[]): number[];
/** Composed matrix for `hue-rotate(hue) brightness(b) saturate(s)`. */
export declare function composedFilterMatrix(hueDegrees: number, brightness: number, saturation: number): number[];
