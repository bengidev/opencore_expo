import { type SharedValue } from 'react-native-reanimated';
import type { BorderBeamColorVariant } from './types';
import { type ResolvedTuning } from './tuning';
export interface PulseBeamProps {
    size: 'pulse-inner' | 'pulse-outside';
    variant: BorderBeamColorVariant;
    theme: 'dark' | 'light';
    staticColors: boolean;
    duration: number;
    borderRadius: number;
    brightness: number;
    saturation: number;
    strength: number;
    width: number;
    height: number;
    clock: SharedValue<number>;
    fade: SharedValue<number>;
    reduceMotion: boolean;
    tuning?: ResolvedTuning;
}
/**
 * Pulse family — breathing glow, no rotation.
 *
 * `pulse-inner`: everything clipped inside the element (one overlay canvas).
 * `pulse-outside`: core + bloom bloom OUTWARD behind the element (a canvas
 * extended `bloomInsetPx` on each side at zIndex -1 — the wrapped child must
 * be opaque, same requirement as the web version), plus a 1px stroke ring
 * overlay above the content.
 */
export declare function PulseBeam(props: PulseBeamProps): import("react").JSX.Element | null;
