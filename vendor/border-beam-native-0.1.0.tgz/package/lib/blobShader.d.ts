/**
 * Generic blob-layer SkSL runtime effect — serves the `line` and pulse
 * families (the rotate family has its own conic shader in rotateShader.ts).
 *
 * A layer is: a stack of radial-gradient ellipse "blobs" with up-to-4-stop
 * alpha falloffs, composited source-over (first blob on top, CSS multiple
 * background semantics), inside a geometry mask (border ring band / rounded
 * rect fill / none), optionally windowed by a radial ellipse mask (the line
 * family's traveling window), then the CSS filter color matrix.
 *
 * Blob record: 14 floats —
 *   [rx, ry, cxPx, cyPx, r, g, b, a0, p1, a1, p2, a2, p3, reserved]
 * Alpha falloff over normalized ellipse distance t:
 *   piecewise linear through (0, a0) → (p1, a1) → (p2, a2) → (p3, 0); 0 after.
 * A plain CSS `color → transparent` gradient is a0=a with the linear
 * subdivision p1=1/3, p2=2/3, p3=1.
 */
export declare const BLOB_FLOATS = 14;
export declare const MAX_LAYER_BLOBS = 16;
export declare const BLOB_LAYER_SKSL = "\nuniform float2 uSize;        // canvas size (may exceed the element for pulse-outside)\nuniform float2 uRectOrigin;  // element rect origin within the canvas\nuniform float2 uRectSize;    // element rect size\nuniform float uRadius;\nuniform float uBorderWidth;\nuniform float uGeomKind;     // 0 ring band, 1 rounded-rect fill, 2 none\nuniform float uEdgeMaskPx;   // rounded-rect fill only; 0 = none\nuniform float uRadial[7];    // [cx, cy, rx, ry, midPos, midAlpha, enabled]\nuniform float uBlobs[224];\nuniform float uBlobCount;\nuniform float uCM[9];\nuniform float uOpacity;\n\nfloat roundedRectSDF(float2 p, float2 halfSize, float radius) {\n  float2 q = abs(p) - halfSize + radius;\n  return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;\n}\n\nfloat4 srcOver(float4 src, float4 dst) {\n  return src + dst * (1.0 - src.a);\n}\n\n// NOTE: SkSL only allows uniform-array indexing by the induction variable of\n// an unrollable loop, so the per-blob alpha falloff is inlined in main below.\nfloat stopAlpha(float t, float a0, float p1, float a1, float p2, float a2, float p3) {\n  if (t >= p3) { return 0.0; }\n  if (t <= 0.0) { return a0; }\n  if (t < p1) { return mix(a0, a1, t / max(p1, 0.0001)); }\n  if (t < p2) { return mix(a1, a2, (t - p1) / max(p2 - p1, 0.0001)); }\n  return mix(a2, 0.0, (t - p2) / max(p3 - p2, 0.0001));\n}\n\nhalf4 main(float2 position) {\n  float2 rectCenter = uRectOrigin + uRectSize * 0.5;\n  float2 rel = position - rectCenter;\n  int kind = int(uGeomKind);\n\n  // Geometry mask.\n  float geom = 1.0;\n  float aa = 1.0;\n  if (kind != 2) {\n    float outerSDF = roundedRectSDF(rel, uRectSize * 0.5, uRadius);\n    float outerCov = 1.0 - smoothstep(-aa, 0.0, outerSDF);\n    if (kind == 1) {\n      geom = outerCov;\n    } else {\n      float innerRadius = max(uRadius - uBorderWidth, 0.0);\n      float innerSDF = roundedRectSDF(rel, uRectSize * 0.5 - uBorderWidth, innerRadius);\n      float innerCov = 1.0 - smoothstep(-aa, 0.0, innerSDF);\n      geom = outerCov - innerCov;\n    }\n    if (geom <= 0.0) { return half4(0.0); }\n  }\n\n  float mask = 1.0;\n\n  // Edge fade (rounded-rect fill only): union of vertical + horizontal\n  // \"solid at edges, transparent uEdgeMaskPx inward\" gradients.\n  if (kind == 1 && uEdgeMaskPx > 0.0) {\n    float2 lp = position - uRectOrigin;\n    float ev = max(1.0 - lp.y / uEdgeMaskPx,\n                   1.0 - (uRectSize.y - lp.y) / uEdgeMaskPx);\n    float eh = max(1.0 - lp.x / uEdgeMaskPx,\n                   1.0 - (uRectSize.x - lp.x) / uEdgeMaskPx);\n    mask *= clamp(max(ev, 0.0) + max(eh, 0.0), 0.0, 1.0);\n  }\n\n  // Radial window mask (line family): 1 @0 \u2192 midAlpha @midPos \u2192 0 @1.\n  if (uRadial[6] > 0.5) {\n    float2 c = float2(uRadial[0], uRadial[1]);\n    float t = length((position - c) / float2(max(uRadial[2], 0.001), max(uRadial[3], 0.001)));\n    float midPos = uRadial[4];\n    float midAlpha = uRadial[5];\n    float m;\n    if (t >= 1.0) {\n      m = 0.0;\n    } else if (t < midPos) {\n      m = mix(1.0, midAlpha, t / max(midPos, 0.0001));\n    } else {\n      m = mix(midAlpha, 0.0, (t - midPos) / max(1.0 - midPos, 0.0001));\n    }\n    mask *= m;\n  }\n  if (mask <= 0.001) { return half4(0.0); }\n\n  // Blob stack: premultiplied source-over, FIRST blob on top.\n  float4 acc = float4(0.0);\n  int nBlobs = int(uBlobCount);\n  for (int i = 15; i >= 0; i--) {\n    if (i < nBlobs) {\n      float rx = max(uBlobs[i * 14 + 0], 0.001);\n      float ry = max(uBlobs[i * 14 + 1], 0.001);\n      float2 c = float2(uBlobs[i * 14 + 2], uBlobs[i * 14 + 3]);\n      float t = length((position - c) / float2(rx, ry));\n      float alpha = stopAlpha(\n        t,\n        uBlobs[i * 14 + 7],\n        uBlobs[i * 14 + 8],\n        uBlobs[i * 14 + 9],\n        uBlobs[i * 14 + 10],\n        uBlobs[i * 14 + 11],\n        uBlobs[i * 14 + 12]\n      );\n      if (alpha > 0.0) {\n        float3 rgb = float3(\n          uBlobs[i * 14 + 4],\n          uBlobs[i * 14 + 5],\n          uBlobs[i * 14 + 6]\n        );\n        acc = srcOver(float4(rgb * alpha, alpha), acc);\n      }\n    }\n  }\n\n  // CSS filter chain (3x3 matrix on unpremultiplied RGB).\n  if (acc.a > 0.0001) {\n    float3 rgb = acc.rgb / acc.a;\n    float3 outRGB = float3(\n      dot(float3(uCM[0], uCM[1], uCM[2]), rgb),\n      dot(float3(uCM[3], uCM[4], uCM[5]), rgb),\n      dot(float3(uCM[6], uCM[7], uCM[8]), rgb)\n    );\n    acc.rgb = clamp(outRGB, 0.0, 1.0) * acc.a;\n  }\n\n  // Clamped like the CSS `opacity` property \u2014 see rotateShader.ts.\n  float finalA = acc.a * geom * mask * clamp(uOpacity, 0.0, 1.0);\n  if (acc.a > 0.0001) {\n    return half4(half3(acc.rgb / acc.a * finalA), half(finalA));\n  }\n  return half4(0.0);\n}\n";
/** Encodes a plain 2-stop (color → transparent) blob. */
export declare function simpleBlob(rx: number, ry: number, cx: number, cy: number, r: number, g: number, b: number, a: number): number[];
/**
 * Encodes a blob from spec-style stops [{r,g,b,a,pos}...] (2-4 stops, pos
 * ascending, last stop is where alpha reaches its final value; alpha is
 * clamped to 0 beyond the last stop). RGB comes from the first stop (CSS
 * premultiplied interpolation keeps RGB constant for same-color fades).
 */
export declare function stopsBlob(rx: number, ry: number, cx: number, cy: number, stops: {
    r: number;
    g: number;
    b: number;
    a: number;
    pos: number;
}[]): number[];
/** Disabled radial-mask uniform. */
export declare const NO_RADIAL: number[];
