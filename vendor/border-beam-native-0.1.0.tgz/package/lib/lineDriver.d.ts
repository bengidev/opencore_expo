/**
 * Per-frame animation values for the `line` family — CSS keyframe tables from
 * the spec, interpolated with the same per-segment timing functions the web
 * version uses (`linear` for travel/edge-fade, `ease-in-out` for
 * breathe/spike/spike2).
 */
/** Cosine ping-pong in [0,1] (same as pulseDriver, exported for worklets). */
export declare function pingPongWorklet(phase: number): number;
/** CSS ease-in-out = cubic-bezier(0.42, 0, 0.58, 1); y for progress x. */
export declare function cssEaseInOut(x: number): number;
/**
 * Samples a keyframe table [[percent, value], ...] at cycle progress p (0..1),
 * applying the timing function per segment (CSS keyframe semantics).
 */
export declare function sampleKeyframes(table: number[][], p: number, easeInOut: boolean): number;
export interface LineFrameValues {
    x: number;
    w: number;
    h: number;
    spike: number;
    spike2: number;
    edge: number;
}
export interface LineKeyframeTables {
    travel: {
        x: number[][];
        w: number[][];
    };
    edgeFade: number[][];
    breathe: number[][];
    spike: number[][];
    spike2: number[][];
    durationScale: {
        travel: number;
        edgeFade: number;
        breathe: number;
        spike: number;
        spike2: number;
    };
}
/** Samples every line animation at absolute time t (seconds). */
export declare function lineFrameValues(tables: LineKeyframeTables, t: number, duration: number): LineFrameValues;
/** Resolves a bloom-gradient size multiplier variable to its current value. */
export declare function multValue(mult: string, v: LineFrameValues): number;
