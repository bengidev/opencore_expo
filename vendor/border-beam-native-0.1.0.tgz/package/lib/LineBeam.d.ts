import { type SharedValue } from 'react-native-reanimated';
import type { BorderBeamColorVariant } from './types';
export declare const blobEffect: import("@shopify/react-native-skia").SkRuntimeEffect;
export interface LineBeamProps {
    variant: BorderBeamColorVariant;
    theme: 'dark' | 'light';
    staticColors: boolean;
    duration: number;
    borderRadius: number;
    brightness: number;
    saturation: number;
    hueRange: number;
    strength: number;
    width: number;
    height: number;
    clock: SharedValue<number>;
    fade: SharedValue<number>;
}
/**
 * The `line` family: bottom traveling glow with breathe and spike animations.
 * Layers mirror the web z-order: inner (1), stroke band (2), bloom (3).
 */
export declare function LineBeam({ variant, theme, staticColors, duration, borderRadius, brightness, saturation, hueRange, strength, width, height, clock, fade, }: LineBeamProps): import("react").JSX.Element | null;
